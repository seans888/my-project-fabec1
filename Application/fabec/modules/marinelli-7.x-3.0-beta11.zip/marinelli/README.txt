**** Marinelli theme ****

http://drupal.org/project/marinelli
http://www.signalkuppe.com

* Before using this theme read carefully the theme guide on drupal.org (http://drupal.org/documentation/theme)
* If you find a bug please report it to http://drupal.org/project/issues/marinelli
* If you find this theme useful, please consider a donation: you can donate using the paypal button on signalkuppe.com

Visit the theme documentation handbook on drupal.org

http://drupal.org/node/1000274