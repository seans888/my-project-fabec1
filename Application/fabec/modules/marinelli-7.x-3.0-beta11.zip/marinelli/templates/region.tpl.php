<!-- start region -->
<div class="region <?php print $classes; ?>">
  <?php print $content; ?>
</div>
<!-- end region -->