
-- SUMMARY --

Please refer to the following for documentation:

Introduction: http://drupal.org/node/578552
Documentation: http://drupal.org/node/578574

For a full description of the module, visit the project page:
  http://drupal.org/project/skinr

To submit bug reports and feature suggestions, or to track changes:
  http://drupal.org/project/issues/skinr


-- REQUIREMENTS --

* @todo Basically, you need nothing, but then again, you need skins.


-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information.


-- CONFIGURATION --


-- CUSTOMIZATION --


-- FAQ --


-- CONTACT --

Current maintainers:
* Balarama Bosch (moonray) - http://drupal.org/user/68275
* Jacine Luisi (Jacine) - http://drupal.org/user/88931

